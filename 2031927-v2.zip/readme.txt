Some Notes

to compile I used

gcc -std=c99 -o coursework1 till.c trie.c product.c

and to execute

./coursework1 .//T5-Products-300.txt
2031927
2031927-v2
203192-v2
It will check for file availability and for parameter on command line