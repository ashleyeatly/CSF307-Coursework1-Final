//
// Created by Ashley Eatly on 21/05/2023.
//

#ifndef CSF307_COURSEWORK1_FINAL_TILL_H
#define CSF307_COURSEWORK1_FINAL_TILL_H
bool file_exists(const char *filename);
void task1(void);
void task2(void);
void task3(void);
void task4(void);
product_t* task3and5(char* pFilename, unsigned int* num_items);
void task3after5(product_t* pProducts,unsigned int num_items);
void task4after3(product_t* pProducts,unsigned int num_items);
void task6(product_t* pProducts, unsigned int num_items);
#endif //CSF307_COURSEWORK1_FINAL_TILL_H
