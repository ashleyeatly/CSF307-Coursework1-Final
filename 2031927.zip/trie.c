//
// Created by Ashley Eatly on 15/05/2023.
//
#include "trie.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <math.h>

/* Allocate a new empty trie.  */
trie_t *new_trie(void) {
    trie_t *pNode = NULL;

    pNode = (trie_t *)malloc(sizeof (trie_t));

    if (pNode) {
        for (int i=0; i < TRIE_CHILDREN; i++) {
            // make sure all the child trie nodes are pointing to NULL
            pNode->pChildrenTries[i] = NULL;
        }
        // and make sure that each pProduct is also pointing to NULL
        pNode->pProduct = NULL;
    }
    return pNode;
}


// Insert a single prouct pointer in the trie chain
void insert_product(trie_t *pRootTrie,product_t *pProduct) {
    trie_t *pCurrentTrie = pRootTrie;

    char buffer[100];
    sprintf(buffer,"%u\n",pProduct->product_code);

    // ensure the index is available outside of the loop
    int index;
    for (int i = 0; i< strlen(buffer); i++) {
        index = buffer[i] - '0';

        trie_t *pNextTrie = pCurrentTrie->pChildrenTries[index];
        if (pNextTrie== NULL) {
            // create  new trie to use
            pNextTrie = new_trie();
            // Make sure the
            pCurrentTrie->pChildrenTries[index] = pNextTrie;
        }
        pCurrentTrie = pNextTrie;
        // just ensure that there is no chance that there is another child
        // not needed because new_trie() does that and we assume that all part_numbers are same length
        // so that there is not a part 123 and part 1234 because that would break this
        // ===========================================
        // This gives segmentation fault so leave for now
        // pCurrentTrie->pChildrenTries[index] = NULL;
    }
    // Finally use the current trie to store pointer to the product
    pCurrentTrie ->pProduct = pProduct;


}

product_t *get_product(trie_t *pRootTrie, unsigned int product_code){
    trie_t *pCurrentTrie = pRootTrie;
    trie_t *pNextTrie = NULL;

    char buffer[100];
    sprintf(buffer,"%u\n",product_code);


    for (int i = 0; i< strlen(buffer); i++) {
        int index = buffer[i] - '0';

        pNextTrie = pCurrentTrie->pChildrenTries[index];
        if (pNextTrie== NULL) {
            return NULL;
        }
        pCurrentTrie = pNextTrie;
    }
    return pCurrentTrie->pProduct;
}

// This causes segmentation fault
unsigned long size_of_trie(trie_t * node) {
    unsigned long total_memory=0;

    if  (!node) {
        return 0;
    }

    for(int i = 0; i < TRIE_CHILDREN; i++) {
        trie_t* next = node->pChildrenTries[i];
        if (next) {
            total_memory += size_of_trie(next);
        }
    }
    return total_memory + sizeof(trie_t);
}

// Remove the trie from memory

void free_trie(trie_t *pTrie) {
    // move across all the possible children in each trie
    // but we need to go down the tree to delete the leaf node and move back up the nodes
    if (pTrie) {
        printf("pTrie %p\n",pTrie);
//        printf("has children ? %d\n", has_children(pTrie));
        printf("has children: %s\n", has_children(pTrie) ? "true" : "false");

        if (has_children(pTrie)) {
            // move across all children
            for (int i = 0; i < TRIE_CHILDREN; i++) {
                trie_t *pNextTrie = pTrie->pChildrenTries[i];
                printf("pTrie %p index %d\n",pNextTrie,i);
                if (pNextTrie) {
                    // recursive free of all tries but starts at the base one
                    printf("pTrie %p index %d it is trying to free it via recursion\n",pNextTrie,i);
                    free_trie(pNextTrie);
                }
            }
        }
        printf("pTrie %p it is trying to free before going back up\n",pTrie);
        free(pTrie);
    }
}

bool has_children(trie_t* pNode) {
    if (!pNode) {
        return false;
    }
    for (int i=0 ; i< TRIE_CHILDREN; i++) {
        if (pNode->pChildrenTries[i]) {
            return true;
        }
    }
    return false;
}
